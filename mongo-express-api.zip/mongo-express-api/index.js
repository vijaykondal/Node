const express = require("express");
const mongoose = require("mongoose");
const courses = require("./routes/courses");
const app = express();
mongoose
  .connect("mongodb://localhost/course-list")
  .then(() => console.log("connected successfully"))
  .catch((err) => console.error("Error connecting to mongodb", err));
app.use(express.json());
app.use("/api/courses", courses);
app.listen(3000, () => console.log("Server running on port 3000"));
