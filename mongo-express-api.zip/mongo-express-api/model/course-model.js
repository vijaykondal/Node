const mongoose = require("mongoose");
const Joi = require("joi");
const courseSchema = mongoose.Schema({
  name: {
    type: String,
    required: true,
    minlength: 5,
    maxlength: 255,
  },

  price: {
    type: String,
    required: true,
  },

  author: {
    type: String,
    required: true,
    minlength: 5,
    maxlength: 255,
  },
});

//Model
const Course = mongoose.model("Course", courseSchema);

function validateCourse(course) {
  const schema = Joi.object({
    name: Joi.string().required().min(5).max(255),
    price: Joi.string().required(),
    author: Joi.string().required().min(5).max(255),
  });
  return schema.validate(course);
}

module.exports = {
  Course: Course,
  validateCourse: validateCourse,
};
