const express = require("express");
const { Course, validateCourse } = require("../model/course-model");
const router = express.Router();
/* const courses = [
  { id: 1, name: "course1" },
  { id: 2, name: "course2" },
  { id: 3, name: "course3" },
]; */

//First we need to create Schema

router.get("", async (req, res) => {
  const course = await Course.find().sort({ name: 1 });
  res.send(course);
});

router.get("/:id", async (req, res) => {
  /*  const course = courses.find((c) => {
    return c.id === parseInt(req.params.id);
  }); */
  const course = await Course.findById(req.params.id);
  if (!course) {
    res.status(404).send("The course with the given ID was not found");
    return;
  }
  res.send(course);
});

router.post("", async (req, res) => {
  const result = validateCourse(req.body);
  if (result.error) {
    res.status(400).send(result.error.details[0].message);
    return;
  }

  /* const course = {
    id: courses.length + 1,
    name: req.body.name,
  };
  courses.push(course); */
  let course = new Course({
    name: req.body.name,
    price: req.body.price,
    author: req.body.author,
  });
  course = await course.save();

  res.send(course);
});

router.put("/:id", async (req, res) => {
  /* const course = courses.find((c) => {
    return c.id === parseInt(req.params.id);
  });
  if (!course) {
    res.status(404).send("The course with the given ID was not found");
    return;
  } */

  const result = validateCourse(req.body);
  if (result.error) {
    res.status(400).send(result.error.details[0].message);
    return;
  }
  try {
    course = await Course.findByIdAndUpdate(
      req.params.id,
      {
        $set: {
          name: req.body.name,
          price: req.body.price,
          author: req.body.author,
        },
      },
      { new: true }
    );
  } catch (error) {
    if (error.name === "castError") {
      res.status(404).send("Course with the given ID was not found ");
      return;
    } else {
      res.status(500).send("Error getting the course");
      return;
    }
  }

  course.name = req.body.name;
  res.send(course);
});

module.exports = router;
