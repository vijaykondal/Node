console.log("before");
getUser(1)
  .then((user) => getRepositories(user.githubUsername))
  .then((result) => console.log(result))
  .catch((err) => console.log(err.message));

console.log("after");

function getUser(id) {
  return new Promise(function (resolve, reject) {
    setTimeout(() => {
      console.log("Reading a user from the database");
      //resolve({ id: id, githubUsername: "varun" });
      reject(new Error("Unable to get User Data"));
    }, 2000);
  });
}

function getRepositories(username) {
  return new Promise(function (resolve, reject) {
    setTimeout(() => {
      console.log("Getting repositories from the github");
      //resolve(["repo1", "repo2", "repo3"]);
      reject("Something Went Wrong");
    }, 2000);
  });
}
