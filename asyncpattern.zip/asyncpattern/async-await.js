console.log("before");
async function displayRepos() {
  try {
    const user = await getUser(1);
    const repos = await getRepositories(user.githubUsername);
    console.log("The repositories are ", repos);
  } catch (err) {
    console.log("Error", err.message);
  }
}

displayRepos();

console.log("after");

function getUser(id) {
  return new Promise(function (resolve, reject) {
    setTimeout(() => {
      console.log("Reading a user from the database");
      //resolve({ id: id, githubUsername: "varun" });
      reject(new Error("Unable to get User Data"));
    }, 2000);
  });
}

function getRepositories(username) {
  return new Promise(function (resolve, reject) {
    setTimeout(() => {
      console.log("Getting repositories from the github");
      resolve(["repo1", "repo2", "repo3"]);
      //reject("Something Went Wrong");
    }, 2000);
  });
}
