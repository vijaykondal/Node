console.log("before");
getUser(1, function (user) {
  getRepositories(user.githubUsername, function (repos) {
    console.log("repositories are", repos);
  });

  //console.log("user is ", user);
});

console.log("after");

function getUser(id, callback) {
  setTimeout(() => {
    console.log("Reading a user from the database");
    callback({ id: id, githubUsername: "varun" });
  }, 2000);
}

function getRepositories(username, callback) {
  setTimeout(() => {
    console.log("Getting repositories from the github");
    callback(["repo1", "repo2", "repo3"]);
  }, 2000);
}
