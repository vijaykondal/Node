const config = require("config");
const helment = require("helmet");
const morgan = require("morgan");
const logger = require("./middleware/logger");
const courses = require("./routes/courses");
const express = require("express");
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

console.log(`process.NODE_ENV is : ${process.env.NODE_ENV}`);
//console.log(`app.get('env') is : ${app.get("env")}`);
console.log(config.get("name"));
console.log(config.get("mail.host"));
console.log(config.get("mail.password"));

app.use(logger);
app.use(helment());
if (app.get("env") == "development") {
  app.use(morgan("tiny"));
}
//crud operation
app.use("/api/courses", courses);
app.listen(3000, () => console.log("Server running on port 3000"));
